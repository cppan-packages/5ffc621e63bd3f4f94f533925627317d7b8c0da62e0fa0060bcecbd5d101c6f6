#include <boost/cstdint.hpp>

typedef boost::uint64_t u64;
typedef boost::int64_t i64;
typedef boost::int32_t i32;

